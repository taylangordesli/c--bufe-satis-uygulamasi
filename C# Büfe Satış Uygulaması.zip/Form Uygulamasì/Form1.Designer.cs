﻿namespace Vize_Uygulama_Ödevi_Taylan_Gördesli
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tboxSu = new System.Windows.Forms.TextBox();
            this.tboxCoke = new System.Windows.Forms.TextBox();
            this.tboxGazoz = new System.Windows.Forms.TextBox();
            this.tboxKBoyAdet = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.suFiyat = new System.Windows.Forms.Label();
            this.cokeFiyat = new System.Windows.Forms.Label();
            this.gazozFiyat = new System.Windows.Forms.Label();
            this.kucukMisirFiyat = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ortaMisirFiyat = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.buyukMisirFiyat = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tboxOgr = new System.Windows.Forms.TextBox();
            this.tboxTam = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tamFiyat = new System.Windows.Forms.Label();
            this.ogrFiyat = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.toplamFiyat = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.hesaplaBTN = new System.Windows.Forms.Button();
            this.temizleBTN = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label27 = new System.Windows.Forms.Label();
            this.kasaFiyat = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.tboxOBoyAdet = new System.Windows.Forms.TextBox();
            this.tboxBBoyAdet = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightCoral;
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.tboxBBoyAdet);
            this.groupBox1.Controls.Add(this.tboxOBoyAdet);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.tboxKBoyAdet);
            this.groupBox1.Controls.Add(this.tboxGazoz);
            this.groupBox1.Controls.Add(this.tboxCoke);
            this.groupBox1.Controls.Add(this.tboxSu);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(21, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(393, 289);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ürünler";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(114, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Su: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Coca Cola:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Gazoz:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Patlamış Mısır:";
            // 
            // tboxSu
            // 
            this.tboxSu.Location = new System.Drawing.Point(165, 35);
            this.tboxSu.Name = "tboxSu";
            this.tboxSu.Size = new System.Drawing.Size(97, 30);
            this.tboxSu.TabIndex = 4;
            this.tboxSu.Text = "0";
            this.tboxSu.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tboxCoke
            // 
            this.tboxCoke.Location = new System.Drawing.Point(165, 80);
            this.tboxCoke.Name = "tboxCoke";
            this.tboxCoke.Size = new System.Drawing.Size(97, 30);
            this.tboxCoke.TabIndex = 5;
            this.tboxCoke.Text = "0";
            this.tboxCoke.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tboxGazoz
            // 
            this.tboxGazoz.Location = new System.Drawing.Point(165, 128);
            this.tboxGazoz.Name = "tboxGazoz";
            this.tboxGazoz.Size = new System.Drawing.Size(97, 30);
            this.tboxGazoz.TabIndex = 6;
            this.tboxGazoz.Text = "0";
            this.tboxGazoz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tboxKBoyAdet
            // 
            this.tboxKBoyAdet.Location = new System.Drawing.Point(162, 177);
            this.tboxKBoyAdet.Name = "tboxKBoyAdet";
            this.tboxKBoyAdet.Size = new System.Drawing.Size(62, 30);
            this.tboxKBoyAdet.TabIndex = 9;
            this.tboxKBoyAdet.Text = "0";
            this.tboxKBoyAdet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.LightCoral;
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.buyukMisirFiyat);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.ortaMisirFiyat);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.kucukMisirFiyat);
            this.groupBox2.Controls.Add(this.gazozFiyat);
            this.groupBox2.Controls.Add(this.cokeFiyat);
            this.groupBox2.Controls.Add(this.suFiyat);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(432, 16);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(656, 289);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ürün Fiyat Listesi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(117, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 23);
            this.label5.TabIndex = 0;
            this.label5.Text = "Su:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 23);
            this.label6.TabIndex = 1;
            this.label6.Text = "Coca Cola:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(84, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 23);
            this.label7.TabIndex = 2;
            this.label7.Text = "Gazoz:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(279, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(214, 23);
            this.label8.TabIndex = 3;
            this.label8.Text = "Patlamış Mısır(Küçük):";
            // 
            // suFiyat
            // 
            this.suFiyat.AutoSize = true;
            this.suFiyat.Location = new System.Drawing.Point(161, 63);
            this.suFiyat.Name = "suFiyat";
            this.suFiyat.Size = new System.Drawing.Size(21, 23);
            this.suFiyat.TabIndex = 4;
            this.suFiyat.Text = "2";
            // 
            // cokeFiyat
            // 
            this.cokeFiyat.AutoSize = true;
            this.cokeFiyat.Location = new System.Drawing.Point(161, 117);
            this.cokeFiyat.Name = "cokeFiyat";
            this.cokeFiyat.Size = new System.Drawing.Size(21, 23);
            this.cokeFiyat.TabIndex = 5;
            this.cokeFiyat.Text = "8";
            // 
            // gazozFiyat
            // 
            this.gazozFiyat.AutoSize = true;
            this.gazozFiyat.Location = new System.Drawing.Point(162, 171);
            this.gazozFiyat.Name = "gazozFiyat";
            this.gazozFiyat.Size = new System.Drawing.Size(21, 23);
            this.gazozFiyat.TabIndex = 6;
            this.gazozFiyat.Text = "6";
            // 
            // kucukMisirFiyat
            // 
            this.kucukMisirFiyat.AutoSize = true;
            this.kucukMisirFiyat.Location = new System.Drawing.Point(493, 61);
            this.kucukMisirFiyat.Name = "kucukMisirFiyat";
            this.kucukMisirFiyat.Size = new System.Drawing.Size(32, 23);
            this.kucukMisirFiyat.TabIndex = 7;
            this.kucukMisirFiyat.Text = "20";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(179, 63);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 23);
            this.label13.TabIndex = 8;
            this.label13.Text = "TL";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(179, 117);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 23);
            this.label14.TabIndex = 9;
            this.label14.Text = "TL";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(179, 171);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 23);
            this.label15.TabIndex = 10;
            this.label15.Text = "TL";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(522, 61);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(33, 23);
            this.label9.TabIndex = 11;
            this.label9.Text = "TL";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(522, 116);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 23);
            this.label10.TabIndex = 14;
            this.label10.Text = "TL";
            // 
            // ortaMisirFiyat
            // 
            this.ortaMisirFiyat.AutoSize = true;
            this.ortaMisirFiyat.Location = new System.Drawing.Point(493, 116);
            this.ortaMisirFiyat.Name = "ortaMisirFiyat";
            this.ortaMisirFiyat.Size = new System.Drawing.Size(32, 23);
            this.ortaMisirFiyat.TabIndex = 13;
            this.ortaMisirFiyat.Text = "25";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(279, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(199, 23);
            this.label12.TabIndex = 12;
            this.label12.Text = "Patlamış Mısır(Orta):";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(522, 169);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 23);
            this.label16.TabIndex = 17;
            this.label16.Text = "TL";
            // 
            // buyukMisirFiyat
            // 
            this.buyukMisirFiyat.AutoSize = true;
            this.buyukMisirFiyat.Location = new System.Drawing.Point(493, 169);
            this.buyukMisirFiyat.Name = "buyukMisirFiyat";
            this.buyukMisirFiyat.Size = new System.Drawing.Size(32, 23);
            this.buyukMisirFiyat.TabIndex = 16;
            this.buyukMisirFiyat.Text = "30";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(279, 169);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(214, 23);
            this.label18.TabIndex = 15;
            this.label18.Text = "Patlamış Mısır(Büyük):";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.LightCoral;
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.tboxTam);
            this.groupBox3.Controls.Add(this.tboxOgr);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(21, 336);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(393, 167);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bilet Satış";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(27, 58);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 23);
            this.label11.TabIndex = 0;
            this.label11.Text = "Öğrenci:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(59, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 23);
            this.label17.TabIndex = 1;
            this.label17.Text = "Tam:";
            // 
            // tboxOgr
            // 
            this.tboxOgr.Location = new System.Drawing.Point(118, 55);
            this.tboxOgr.Name = "tboxOgr";
            this.tboxOgr.Size = new System.Drawing.Size(97, 30);
            this.tboxOgr.TabIndex = 5;
            this.tboxOgr.Text = "0";
            this.tboxOgr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tboxTam
            // 
            this.tboxTam.Location = new System.Drawing.Point(118, 101);
            this.tboxTam.Name = "tboxTam";
            this.tboxTam.Size = new System.Drawing.Size(97, 30);
            this.tboxTam.TabIndex = 6;
            this.tboxTam.Text = "0";
            this.tboxTam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(268, 39);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 23);
            this.label19.TabIndex = 11;
            this.label19.Text = "Adet";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(268, 84);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 23);
            this.label20.TabIndex = 12;
            this.label20.Text = "Adet";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(268, 132);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 23);
            this.label21.TabIndex = 13;
            this.label21.Text = "Adet";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(221, 104);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 23);
            this.label22.TabIndex = 14;
            this.label22.Text = "Adet";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(221, 58);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(51, 23);
            this.label23.TabIndex = 13;
            this.label23.Text = "Adet";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.LightCoral;
            this.groupBox4.Controls.Add(this.tamFiyat);
            this.groupBox4.Controls.Add(this.ogrFiyat);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Location = new System.Drawing.Point(21, 530);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(393, 167);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Bilet Fiyat Listesi";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(39, 53);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(85, 23);
            this.label40.TabIndex = 0;
            this.label40.Text = "Öğrenci:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(71, 103);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(53, 23);
            this.label41.TabIndex = 1;
            this.label41.Text = "Tam:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(158, 103);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(33, 23);
            this.label24.TabIndex = 11;
            this.label24.Text = "TL";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(158, 53);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(33, 23);
            this.label25.TabIndex = 10;
            this.label25.Text = "TL";
            // 
            // tamFiyat
            // 
            this.tamFiyat.AutoSize = true;
            this.tamFiyat.Location = new System.Drawing.Point(130, 103);
            this.tamFiyat.Name = "tamFiyat";
            this.tamFiyat.Size = new System.Drawing.Size(32, 23);
            this.tamFiyat.TabIndex = 13;
            this.tamFiyat.Text = "30";
            // 
            // ogrFiyat
            // 
            this.ogrFiyat.AutoSize = true;
            this.ogrFiyat.Location = new System.Drawing.Point(130, 53);
            this.ogrFiyat.Name = "ogrFiyat";
            this.ogrFiyat.Size = new System.Drawing.Size(32, 23);
            this.ogrFiyat.TabIndex = 12;
            this.ogrFiyat.Text = "26";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.LightCoral;
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.kasaFiyat);
            this.groupBox5.Controls.Add(this.label30);
            this.groupBox5.Controls.Add(this.temizleBTN);
            this.groupBox5.Controls.Add(this.hesaplaBTN);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.toplamFiyat);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Location = new System.Drawing.Point(431, 336);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(284, 360);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Hesap:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.Location = new System.Drawing.Point(47, 82);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 32);
            this.label26.TabIndex = 0;
            this.label26.Text = "Toplam:";
            // 
            // toplamFiyat
            // 
            this.toplamFiyat.AutoSize = true;
            this.toplamFiyat.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.toplamFiyat.Location = new System.Drawing.Point(153, 82);
            this.toplamFiyat.Name = "toplamFiyat";
            this.toplamFiyat.Size = new System.Drawing.Size(30, 32);
            this.toplamFiyat.TabIndex = 1;
            this.toplamFiyat.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.Location = new System.Drawing.Point(232, 82);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(46, 32);
            this.label28.TabIndex = 2;
            this.label28.Text = "TL";
            // 
            // hesaplaBTN
            // 
            this.hesaplaBTN.Location = new System.Drawing.Point(53, 198);
            this.hesaplaBTN.Name = "hesaplaBTN";
            this.hesaplaBTN.Size = new System.Drawing.Size(191, 53);
            this.hesaplaBTN.TabIndex = 3;
            this.hesaplaBTN.Text = "HESAPLA";
            this.hesaplaBTN.UseVisualStyleBackColor = true;
            this.hesaplaBTN.Click += new System.EventHandler(this.hesaplaBTN_Click);
            // 
            // temizleBTN
            // 
            this.temizleBTN.Location = new System.Drawing.Point(53, 267);
            this.temizleBTN.Name = "temizleBTN";
            this.temizleBTN.Size = new System.Drawing.Size(191, 53);
            this.temizleBTN.TabIndex = 4;
            this.temizleBTN.Text = "TEMİZLE";
            this.temizleBTN.UseVisualStyleBackColor = true;
            this.temizleBTN.Click += new System.EventHandler(this.temizleBTN_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(741, 336);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(347, 360);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.Location = new System.Drawing.Point(232, 135);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 32);
            this.label27.TabIndex = 7;
            this.label27.Text = "TL";
            // 
            // kasaFiyat
            // 
            this.kasaFiyat.AutoSize = true;
            this.kasaFiyat.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kasaFiyat.Location = new System.Drawing.Point(153, 135);
            this.kasaFiyat.Name = "kasaFiyat";
            this.kasaFiyat.Size = new System.Drawing.Size(30, 32);
            this.kasaFiyat.TabIndex = 6;
            this.kasaFiyat.Text = "0";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.Location = new System.Drawing.Point(73, 135);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(85, 32);
            this.label30.TabIndex = 5;
            this.label30.Text = "Kasa:";
            // 
            // tboxOBoyAdet
            // 
            this.tboxOBoyAdet.Location = new System.Drawing.Point(162, 213);
            this.tboxOBoyAdet.Name = "tboxOBoyAdet";
            this.tboxOBoyAdet.Size = new System.Drawing.Size(62, 30);
            this.tboxOBoyAdet.TabIndex = 14;
            this.tboxOBoyAdet.Text = "0";
            this.tboxOBoyAdet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tboxBBoyAdet
            // 
            this.tboxBBoyAdet.Location = new System.Drawing.Point(162, 249);
            this.tboxBBoyAdet.Name = "tboxBBoyAdet";
            this.tboxBBoyAdet.Size = new System.Drawing.Size(62, 30);
            this.tboxBBoyAdet.TabIndex = 15;
            this.tboxBBoyAdet.Text = "0";
            this.tboxBBoyAdet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(230, 252);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(152, 23);
            this.label29.TabIndex = 18;
            this.label29.Text = "Adet Büyük Boy";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(230, 216);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(137, 23);
            this.label31.TabIndex = 17;
            this.label31.Text = "Adet Orta Boy";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(230, 180);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(152, 23);
            this.label32.TabIndex = 16;
            this.label32.Text = "Adet Küçük Boy";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Crimson;
            this.ClientSize = new System.Drawing.Size(1106, 709);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Büfe Satış Uygulaması";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tboxKBoyAdet;
        private System.Windows.Forms.TextBox tboxGazoz;
        private System.Windows.Forms.TextBox tboxCoke;
        private System.Windows.Forms.TextBox tboxSu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label buyukMisirFiyat;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label ortaMisirFiyat;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label kucukMisirFiyat;
        private System.Windows.Forms.Label gazozFiyat;
        private System.Windows.Forms.Label cokeFiyat;
        private System.Windows.Forms.Label suFiyat;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tboxTam;
        private System.Windows.Forms.TextBox tboxOgr;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label tamFiyat;
        private System.Windows.Forms.Label ogrFiyat;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button temizleBTN;
        private System.Windows.Forms.Button hesaplaBTN;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label toplamFiyat;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label kasaFiyat;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox tboxBBoyAdet;
        private System.Windows.Forms.TextBox tboxOBoyAdet;
    }
}

