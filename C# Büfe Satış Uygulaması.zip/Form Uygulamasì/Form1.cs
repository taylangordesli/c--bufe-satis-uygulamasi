﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vize_Uygulama_Ödevi_Taylan_Gördesli
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int kasaTutar = 0;
        public void hesaplaBTN_Click(object sender, EventArgs e)
        {
            int ogrBilet, tamBilet, su, coke, gazoz, kBoyMisir, oBoyMisir, bBoyMisir; 
            int toplam;
            ogrBilet = Convert.ToInt16(ogrFiyat.Text);
            tamBilet = Convert.ToInt16(tamFiyat.Text);
            su = Convert.ToInt16(suFiyat.Text);
            coke = Convert.ToInt16(cokeFiyat.Text);
            gazoz = Convert.ToInt16(gazozFiyat.Text);
            kBoyMisir = Convert.ToInt16(kucukMisirFiyat.Text);
            oBoyMisir = Convert.ToInt16(ortaMisirFiyat.Text);
            bBoyMisir = Convert.ToInt16(buyukMisirFiyat.Text);
            int ogrAdet, tamAdet, suAdet, cokeAdet, gazozAdet, kBoyAdet, oBoyAdet, bBoyAdet;
            ogrAdet = Convert.ToInt16(tboxOgr.Text);
            tamAdet = Convert.ToInt16(tboxTam.Text);
            suAdet = Convert.ToInt16(tboxSu.Text);
            cokeAdet = Convert.ToInt16(tboxCoke.Text);
            gazozAdet = Convert.ToInt16(tboxGazoz.Text);
            kBoyAdet = Convert.ToInt16(tboxKBoyAdet.Text);
            oBoyAdet = Convert.ToInt16(tboxOBoyAdet.Text);
            bBoyAdet = Convert.ToInt16(tboxBBoyAdet.Text);
            int misirToplam = (kBoyAdet * kBoyMisir) + (oBoyAdet * oBoyMisir) + (bBoyAdet * bBoyMisir);
            int suToplam = su * suAdet;
            int cokeToplam = coke * cokeAdet;
            int gazozToplam = gazoz * gazozAdet;
            int urunToplam = misirToplam + suToplam + cokeToplam + gazozToplam;
            int biletToplam = (ogrBilet * ogrAdet) + (tamBilet * tamAdet);
            toplam = urunToplam + biletToplam;
            kasaTutar = kasaTutar + toplam;
            toplamFiyat.Text = toplam.ToString();
            kasaFiyat.Text = kasaTutar.ToString();
        }

        private void temizleBTN_Click(object sender, EventArgs e)
        {
            toplamFiyat.Text = 0.ToString();
            tboxBBoyAdet.Text = 0.ToString();
            tboxCoke.Text = 0.ToString();
            tboxGazoz.Text = 0.ToString();
            tboxKBoyAdet.Text = 0.ToString();
            tboxOBoyAdet.Text = 0.ToString();
            tboxBBoyAdet.Text = 0.ToString();
            tboxSu.Text = 0.ToString();
            tboxOgr.Text = 0.ToString();
            tboxTam.Text = 0.ToString();
        }
    }
}
